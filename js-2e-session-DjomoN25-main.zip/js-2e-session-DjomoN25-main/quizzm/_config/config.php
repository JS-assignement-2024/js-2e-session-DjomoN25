<?php
// Configuration de la base de données intégrée dans db.php
define('DB_HOST', 'localhost');
define('DB_NAME', 'calcul');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
